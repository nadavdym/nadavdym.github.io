%written by Nadav Dym. comments can be sent to nadavdym@gmail.com

%this script conducts the interpolation of two given polygons

%parameters to be set
DISPLAY_MOVIE=true;
FRAMES_PER_SECOND=10; 
TIMES=1/25*(0:25);
DISPLAY_INDIVIDUALLY=false;
SAMPLE_VECTOR=1:length(TIMES);


%set interpolation options as you wish
options=DefaultInterpolationOptions; 
options.n=length(TIMES);
options.Times=TIMES;

%load example.
%tools
%load('Pliers');
%load('Scissors');
%leaves
%load('LeavesOneAndFour');
%load('LeavesOneAndTwo');
load('LeavesOneAndThree');
%different  rotation index example
%load('pants');

Z=cell(1,options.n);

%check whether input is legal, i.e. whether all edges are positive
Positive0=CheckPositiveLengths(Z0);
if ~Positive0
    error('not all edges of Z0 have positive length');
end
Positive1=CheckPositiveLengths(Z1);
if ~Positive1
    error('not all edges of Z1 have positive length');
end

%check whether rotation indices are identical, and interpolate accordingly
[add0,add1,same_rot]=auto_choose_addition(Z0,Z1);
if same_rot %rotation index is identical
 [Z,Tc]=Interpolate(Z0,Z1,options);   
else
[Z,Tc]= DiffRotInterpolate(Z0,Z1,options,add0,add1);
end

%display movie
if DISPLAY_MOVIE
movie_options=DefaultMovieOptions();
movie_options.fps=FRAMES_PER_SECOND;
PolyMovie=Polygons2Movie(Z,movie_options);
end


if DISPLAY_INDIVIDUALLY
display_opt=DefaultMovieOptions();
Fig=Polygons2IndividualStills(Z,display_opt,SAMPLE_VECTOR,false);
end
