function k=FindPolyCorrectK(Tc0,Tc1)
%finds the optimal k so that the average of phi0i+2 pi k-phi1i is minimal
%we use the computation described in pdf, for polygons instead of functions
Lavg=1/2*(Tc0.L+Tc1.L);
phi0=ExternalAnglesToSelfAngles(Tc0.phi1,Tc0.theta);
phi1=ExternalAnglesToSelfAngles(Tc1.phi1,Tc1.theta);

%the minimum over R is given by
kR=((phi0-phi1)*Lavg')/(2*pi*sum(Lavg));
%compute objective value, for the floor and ceiling of kR
obj_up=(phi1+2*pi*ceil(kR)*ones(1,length(phi0))-phi0).^2*Lavg';
obj_down=(phi1+2*pi*floor(kR)*ones(1,length(phi0))-phi0).^2*Lavg';
if obj_up<obj_down
    k=ceil(kR);
else
    k=floor(kR);
end %if
end %function