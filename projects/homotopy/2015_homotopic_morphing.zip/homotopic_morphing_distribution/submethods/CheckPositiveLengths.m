function Positive = CheckPositiveLengths(Z)
%input: A polygon
%output: Positive=true if all lengths are positive

epsilon=10^(-5); % a parameter determining what is so small as to be considered zero
Tc=Cartesian2Turtle(Z');
M=max(Tc.L);
m=min(Tc.L);
if (m/M)<epsilon || M==0
    Positive=false;
else
    Positive=true;
end

end

