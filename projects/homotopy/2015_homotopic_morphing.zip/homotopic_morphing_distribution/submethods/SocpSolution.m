function LSol=SocpSolution(A,IntL,scale_constraint,S)
%we are given the interpolated  lengths at some time t, and a matrix defining
%constraints A*L=0. If scale_constraint=true we add the constraint that the
%length of the curves should be S
%we return the SocpSolution
n=length(IntL);

%L is the solution of the following QP problem
L=sdpvar(n,1);
x=sdpvar(n,1);
w=sdpvar(n,1);
z=sdpvar(3,n);
IntL=IntL';

ClosedCon=[A*L==0];
%F = set(rcone(x,1,1));
SlackCon1=[x==(L-1/2*IntL)./sqrt(IntL)];
SlackCon2=[z==[L'+w' ;2*ones(1,n); L'-w'] ]; %bug before hand: was x here instead of L
RconeCon=cone(z);
Objective=[x'*x+(IntL.^2)'*w];

ops=sdpsettings;
ops.solver='mosek';
ops.debug=1;
if scale_constraint
    ScaleCon=[S==sum(L)];
    sol = solvesdp(ClosedCon+RconeCon+SlackCon1+SlackCon2+ScaleCon,Objective,ops);
else
sol = solvesdp(ClosedCon+RconeCon+SlackCon1+SlackCon2,Objective,ops);
end
LSol= double(L);
if ~(sol.problem == 0)
 display('Hmm, something went wrong!');
 sol.info
 yalmiperror(sol.problem)
end

