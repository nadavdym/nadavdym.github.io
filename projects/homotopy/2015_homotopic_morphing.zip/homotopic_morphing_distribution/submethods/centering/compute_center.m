function Center=compute_center(Z)
%give a polygon Z with Z(:,i) the i-th vertex, we compute the center of the
%polygon
x=Z(:,1);
y=Z(:,2);
n=length(x);

%compute lengths. L(1)=norm(Z(1,:)-Z(n,:)). L(i)=norm(Z(i,:)-Z(i-1,:))
Tc=Cartesian2Turtle(Z');
L=Tc.L;

%compute arc-length average:
TotalLength=sum(L);
%first computer the average values on every edge
LocalxAvg(1)=1/2*(x(1)+x(n));
LocalyAvg(1)=1/2*(y(1)+y(n));
LocalxAvg(1,2:n)=1/2*(x(2:n)+x(1:(n-1)));
LocalyAvg(1,2:n)=1/2*(y(2:n)+y(1:(n-1)));


xAvg=1/TotalLength*(L*LocalxAvg');
yAvg=1/TotalLength*(L*LocalyAvg');

Center=[xAvg yAvg];
end