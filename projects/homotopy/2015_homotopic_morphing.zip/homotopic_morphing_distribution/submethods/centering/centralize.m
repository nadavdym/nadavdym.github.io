function CenteredZ=centralize(Z)
%give a polygon Z with Z(i,:) the i-th vertex, we translate it so that its
%center is at  the origin
x=Z(:,1);
y=Z(:,2);
n=length(x);

%calculate the center
c=compute_center(Z);

%translate Z so the CenteredZ has center 0
CenteredZ=Z-(ones(n,1)*c);
end