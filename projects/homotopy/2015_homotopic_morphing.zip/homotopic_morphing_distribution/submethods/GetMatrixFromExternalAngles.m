function A=GetMatrixFromExternalAngles(theta)
%given a vector of external angles, we return the matrix A from the
%equation A*L=0
phi=ExternalAnglesToSelfAngles(0,theta); %the initial external angle does not matter as far as A is concerned
for i=1:length(theta)
    A(:,i)=CompExp(phi(i))';
end
end