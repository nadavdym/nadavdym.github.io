function alpha=FindArgument(z)
%given a vector with two entries, which we think of as a complex number, 
%return its argument
alpha=angle(complex(z(1),z(2)));
end