function phi=ExternalAnglesToSelfAngles(phi_1,theta)
%given a list of external angles, and the angle phi_i of the vector
%z_1-z_0, we return the vector phi with phi(i)=z_{i+1}-z_i. We think of
%phi(n) as phi(0) and theta(n)as theta(0)
n=length(theta);
phi(1)=phi_1;
for i=1:(n-1)
    phi(i+1)=phi(i)+theta(i);
end
