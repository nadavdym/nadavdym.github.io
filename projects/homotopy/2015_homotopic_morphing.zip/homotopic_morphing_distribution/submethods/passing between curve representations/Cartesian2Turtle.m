function Tc=Cartesian2Turtle(Z)
%given a polygonal curve represented by Z with Z(:,i) the i th vertex, we
%return the turtle representation of the curve. z0=Z(:,n)
n=length(Z(1,:));
Tc.z0=Z(:,n);
Tc.phi1=angle(complex(Z(1,1)-Z(1,n),Z(2,1)-Z(2,n)));
%external angles
Tc.theta(1)=FindExternalAngle(Z(:,1)-Z(:,n),Z(:,2)-Z(:,1));
Tc.theta(n)=FindExternalAngle(Z(:,n)-Z(:,n-1),Z(:,1)-Z(:,n));
for i=2:(n-1)
    Tc.theta(i)=FindExternalAngle(Z(:,i)-Z(:,i-1),Z(:,i+1)-Z(:,i));
end
%lengths
Tc.L=zeros(1,n);
Tc.L(1)=norm(Z(:,1)-Z(:,n));
for i=2:n
    Tc.L(i)=norm(Z(:,i)-Z(:,i-1));
end
end