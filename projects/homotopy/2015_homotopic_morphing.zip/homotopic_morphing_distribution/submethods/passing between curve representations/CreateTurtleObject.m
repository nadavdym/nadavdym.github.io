function Tc=CreateTurtleObject(L,theta,z0,phi1)
Tc.L=L;
Tc.theta=theta;
if nargin==2
    z0=[0 0]';
    phi1=0;
end
Tc.z0=z0;
Tc.phi1=phi1;
end