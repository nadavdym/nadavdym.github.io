function L=computeLengths(Z)
%given a polygon Z where Z(i,:) is the i vertex, computer length vector, 
%where L(1)=|Z(1,:)-Z(n,:)|, L(i)=|Z(i,:)-Z(i-1,:)|
n=length(Z(:,1));
L=ones(1,n);
L(1)=norm(Z(1,:)-Z(n,:));
for i=2:n
    L(i)=norm(Z(i,:)-Z(i-1,:));
end
end