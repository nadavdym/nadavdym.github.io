function Z=TurtletoCartesian(Tc)
%We are given the turtle representation of a polygonal curve given by an initial
%point, the angle of z1-z0, a vector of external angles, and a vector  of lengths. We return the
%cartesian representation of the polygonal curve
n=length(Tc.theta);
phi=ExternalAnglesToSelfAngles(Tc.phi1,Tc.theta);
Z(:,n)=Tc.z0;
Z(:,1)=Tc.z0+Tc.L(1).*CompExp(phi(1))';
for i=2:(n-1)
    Z(:,i)=Z(:,i-1)+Tc.L(i).*CompExp(phi(i))';
end
    