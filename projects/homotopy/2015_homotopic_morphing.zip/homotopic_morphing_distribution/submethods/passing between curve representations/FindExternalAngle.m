function theta=FindExternalAngle(z1,z2)
%given two two dimensional vector zi, find the external angle between them,
%assuming the orientation is 'from z1 to z2'.
FirstZ=complex(z1(1),z1(2));
SecondZ=complex(z2(1),z2(2));
FirstArg=angle(FirstZ);
SecondArg=angle(SecondZ);

if SecondArg>=FirstArg
    if SecondArg-FirstArg<pi
        theta=SecondArg-FirstArg;
    else
        theta=SecondArg-2*pi-FirstArg;
    end
else
    if FirstArg-SecondArg<pi
        theta=SecondArg-FirstArg;
    else
        theta=SecondArg-(FirstArg-2*pi);
    end
end