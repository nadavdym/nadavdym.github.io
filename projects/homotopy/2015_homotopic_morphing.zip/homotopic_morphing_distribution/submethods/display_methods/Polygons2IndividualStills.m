function Fig=Polygons2IndividualStills(Z,display_opt,SampleVector,Save)
%display each polygon as an individual image, at each time specified by the
%SAMPLE_VECTOR. Use identical axis
if isempty(display_opt)
    display_opt=DefaultMovieOptions();
end
if display_opt.axis_options==2
Bounds=CalculateUniformBounds(Z);
end
for i=1:length(SampleVector)
    Fig{i}=figure;
    h=gca;
    hold on;
    switch display_opt.axis_options
        case 1 
            ContinuousAxis(Z{SampleVector(i)});
        case 2
            axis(Bounds);
            %this command puts white dots at the corners of the bounding
            %box of the figure:
            %scatter([Bounds(1) Bounds(1) Bounds(2) Bounds(2)],[Bounds(3) Bounds(4) Bounds(3) Bounds(4)],'w' );
    end %switch
    axis off;
    if isempty(display_opt.point_size)
       ContinuousDrawPolygon(h,Z{SampleVector(i)},[]); 
    else
    DrawPolygon(h,Z{SampleVector(i)},display_opt.point_size);
    end
    hold off;
    if nargin==4 && Save
        uisave('Fig');
    end
end
end