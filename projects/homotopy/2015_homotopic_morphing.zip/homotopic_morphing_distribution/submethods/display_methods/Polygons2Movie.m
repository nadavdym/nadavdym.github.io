function Movie=Polygons2Movie(Z,options)
%we are given Z such that Z{i} is the i-th polygon, and display a movie
if nargin==1
options=DefaultMovieOptions();
end
PolyNum=max(length(Z)); %this is the number of polygons given


if options.axis_options==2 %use a fixed frame
 Bounds=CalculateUniformBounds(Z);
end

for i=1:PolyNum
   f=figure;
   hold on;
   switch options.axis_options
       case 1
   ContinuousAxis(Z{i});
       case 2
           axis(Bounds);
   end

   h=gca;
   ContinuousDrawPolygon(h,Z{i});
   str=sprintf('t= %.2f . ',(i-1)/(PolyNum-1));
   title(str);
   Movie(i)=getframe;
   hold off;
   close(f);
end
figure;
hold on;
switch options.axis_options
       case 1
   ContinuousAxis(Z{i});
       case 2
           axis(Bounds);
end
   
movie(Movie,1,options.fps);
hold off;
end