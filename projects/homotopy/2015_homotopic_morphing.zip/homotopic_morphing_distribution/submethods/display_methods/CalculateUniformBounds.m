function Bounds=CalculateUniformBounds(Z)
%we recieve Z s.t. Z{i} is a n by 2 polygon, and return the extremal
%x and y values of all Z{i}, and so that axis will be equal
%since this was written for Z with Z(:,i) the i vertex, we transpose Z
Z=Z';

n=length(Z);
for i=1:n
    TempZ=Z{i};
    xMin(i)=min(TempZ(:,1));
    xMax(i)=max(TempZ(:,1));
    yMin(i)=min(TempZ(:,2));
    yMax(i)=max(TempZ(:,2));
end
xMin=min(xMin);
xMax=max(xMax);
yMin=min(yMin);
yMax=max(yMax);

m=min([xMin yMin]);
M=max([xMax yMax]);
space=1/50*(M-m); %this is the space we give the image from boundaries
%Bounds=[xMin-space,xMax+space,yMin-space,yMax+space];
Bounds=[m M m M];
end
    