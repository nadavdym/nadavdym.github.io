function ContinuousAxis(z)
%given a polygon z such that Z(i,:) is the i-th vertex, returns a handle to
%the axis so that the display of the interpolation won't have jumps

%since this was written for Z with Z(:,i) the i vertex, we transpose Z
z=z';

delta=0.1; %this is the relative distance of the axis limits from the shape

xMax=max(z(1,:));
xMin=min(z(1,:));
xSize=xMax-xMin;

yMax=max(z(2,:));
yMin=min(z(2,:));
ySize=yMax-yMin;

axis([xMin-delta*xSize,xMax+delta*xSize,yMin-delta*ySize,yMax+delta*ySize]);
end