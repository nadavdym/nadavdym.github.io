function f=ContinuousDrawPolygon(h,Z,PointSize,LineWidth)
%given a polygonal curve in standard representation, where Z(i,:) is the
%i-th vertex, we draw the given polygon, with PointSize as specified. h is a pointer to some axis.
%in ContinuousDrawPolygon, corlors change gradually
if isempty(h)
    f=figure;
    h=gca;
end
if nargin<4
    LineWidth=0.5;
end


axis off;

%set colormap

%CM=length(cm(:,1));
%find lengths to distribute colors. Lets assume lengths are uniformly
%distributed to save work :) so we just choose


x=[Z(:,1); Z(1,1)];
y=[Z(:,2); Z(1,2)];
n=length(x)-1;
%set colormap (from Yaron)
t = 0.25;
my_color_map = (1-t)*hsv(n) + t*zeros(size(hsv(n)));
cm=colormap(my_color_map);

hold on;
for i=1:n
plot(h,x([i i+1]),y([i i+1]),'color',cm(i,:),'LineWidth',LineWidth);
end
hold off;

%if user doesn't want to draw points, end here.
if (nargin==2) || isempty(PointSize) 
    return;
end

hold on;
Colors=(1/(n-1))*(0:(n-1));
handle=scatter(Z(:,1),Z(:,2),PointSize,Colors,'fill');
set(handle,'MarkerEdgeColor','k','LineWidth',1);
hold off;
end