function options=DefaultMovieOptions()
%set default options for movies
options.point_size=[];
options.fps=12; % fps=frames per second
%axis options: 1 to scale continuously
%              2 to hold frame constant throughout movie  
%              3 to leave at matlab default
%              4 axis equal
options.axis_options=2; 
end