function [z]=CompExp(theta)
%recieves an angle theta and returns e^(i theta)
z=[cos(theta),sin(theta)];
end