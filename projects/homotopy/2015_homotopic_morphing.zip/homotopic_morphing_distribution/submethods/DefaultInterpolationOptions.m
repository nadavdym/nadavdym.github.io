
function options=DefaultInterpolationOptions()
%sets the default options for interpolation
options.Times=1/4*(0:4);
options.n=5; %number of interpolations to conduct
end