function d=get_diameter(Z)
%input: a 2 by n polygon
%output: the diameter of the polygon
Dist=pdist(Z);
d=max(Dist);
end %function