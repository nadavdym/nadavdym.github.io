This code morphs between two closed curve, using the algorithm described in "Homotopic Morphing of Planar Curves". 
If the turning number of source and target isn't identical, the algoirthm described in the paper for curves with different turning
numbers is applied.

Run the  code via ScriptInterpolation. You can either use one of the examples supplied there, or load your own examples, 
by defining polygons Z0 and Z1.
the "input" Z0 and Z1 are n by 2 polygons. the first and last vertex should not be identical. for example the unit square
should be represented as

Z0=0 0
   1 0
   1 1
   0 1

If you find any bugs, or have any question, please contact me at nadavdym@gmail.com

A remark on the terminology used in the code: We use the phrase rotation index instead of turning number. These are two 
different common names for the same notion.

Enjoy! 

