%written by nadav dym. comments can be sent to nadavdym@gmail.com

function [ZCell,TcCell]= DiffRotInterpolate(Z0,Z1,options,add0,add1)
%given two polygonal curves with different rotation index, compute and display
%n samples of the interpolated curve. 
%ZCell is a cell array, such that ZCell{i} is a polygon. 
%TcCell is a cell array, where TcCell{i} is the turtle representation of 
%ZCell{i}. add_i are vectors to add to theta_i such that sum of angles will
%be equal for both curves.
if nargin==2
    options=DefaultInterpolationOptions;
end

PolygonLength=length(Z0(:,1));
%we take Z0 Z1 centralized.
Z0=centralize(Z0);
Z1=centralize(Z1);

%for scaling: we compute solution in relative length (normalize to length
%1. We will then scale so that the diameter changes linearly
D0=get_diameter(Z0);
D1=get_diameter(Z1);
S0=sum(computeLengths(Z0));
S1=sum(computeLengths(Z1));

Tc0=Cartesian2Turtle(Z0');
Tc0.theta=Tc0.theta+add0;
Tc1=Cartesian2Turtle(Z1');
Tc1.theta=Tc1.theta+add1;
Tc1.phi1=Tc1.phi1+2*pi*FindPolyCorrectK(Tc0,Tc1);

%when user doesn't specify options, pick default options
if nargin==2
    options=DefaultInterpolationOptions();
end
%calculate lengths of Z0 and Z1 and normalize
t=options.Times;
options.n=length(t);
figure;
for i=1:options.n
    %pick arbitrary initial conditions
    TempTc.z0=[0 0]';
    TempTc.phi1=0;
    TempTc.L=zeros(1,PolygonLength);
    %find the turtle representation of the new curve
    TempTc.theta=(1-t(i))*Tc0.theta+t(i)*Tc1.theta;
    %find the "model" LTemp, scale_invariant unless user chooses otherwise
    %LTemp=ScaleInvLengths(t(i),Tc0.L,Tc1.L,options);
    LTemp=(1-t(i))*Tc0.L/S0+t(i)*Tc1.L/S1;
    A=GetMatrixFromExternalAngles(TempTc.theta);
    TempTc.L=SocpSolution(A,LTemp,true,1);
    
    
    %pick appropriate initial angle
    TempTc.phi1=(1-t(i))*Tc0.phi1+t(i)*Tc1.phi1;
    %move to cartesian
    TempZ=TurtletoCartesian(TempTc)';
    %now centralize TempZ and scale, if we're at our method
    TempZ=centralize(TempZ);
         d=get_diameter(TempZ);
         D=(1-t(i))*D0+t(i)*D1;
         %scale TempZ so that diameter changes linearly
         TempZ=(D/d)*TempZ;
    
    %modify turtle  representation accordingly
    TempTc.z0=TempZ(PolygonLength,:);
    TempTc.phi1=angle(complex(TempZ(1,1)-TempZ(PolygonLength,1),TempZ(1,2)-TempZ(PolygonLength,2)));

    %save results.
    TcCell{i}=TempTc;
    ZCell{i}=TempZ;
    
end

end
    