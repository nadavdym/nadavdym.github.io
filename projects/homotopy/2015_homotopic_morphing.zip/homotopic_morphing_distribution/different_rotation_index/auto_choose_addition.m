function [add1,add2,same_rot]=auto_choose_addition(Z1,Z2)
%checks whether polygons have the same rotation index.
%If not, computes automatically the vertices in which to add a phase of 2pi
Tc1=Cartesian2Turtle(Z1');
theta(1,:)=Tc1.theta;
Tc2=Cartesian2Turtle(Z2');
theta(2,:)=Tc2.theta;
rot(1)=sum(Tc1.theta)/(2*pi);
rot(2)=sum(Tc2.theta)/(2*pi);
fprintf('rotation index:');
display(rot );
%check whether rotation index is different
epsilon=10^(-5); %tolerance to error in rotation index calculation
if abs(rot(1)-rot(2))<epsilon
    fprintf('curves have same rotation index');
    same_rot=true;
    add1=0;
    add2=0;
    return
else
    same_rot=false;
    fprintf('curves have different rotation indices');
end

%find which one is larger
if rot(2)>rot(1)
    M=2;
    m=1;
else
    M=1;
    m=2;
end %if
k=rot(M)-rot(m);
n=length(Tc1.theta);
[Diff,I]=sort(theta(m,:)+2*pi*ones(1,n)-theta(M,:));
Add(m,:)=zeros(1,n);
for i=1:k
    Add(m,I(i))=2*pi;
end
Add(M,:)=zeros(1,n);

add1=Add(1,:);
add2=Add(2,:);

end %function