function x=colstack(X)
x=X(:);
end