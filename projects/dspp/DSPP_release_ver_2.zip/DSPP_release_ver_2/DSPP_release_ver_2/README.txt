-----------------------------------------------------------------------------------------------------------------
Code for: "DS++: A flexible, scalable and provably tight relaxation for matching problems" ,SIGGRAPH Asia 2017
-----------------------------------------------------------------------------------------------------------------
This code supports matching n points on the first shape to k points on the second shape (k<=n).
Run demo.m for a quick demostration

questions regarding the code can be sent to nadavdym@gmail.com

Code written by Haggai Maron and Nadav Dym. 
Please cite:
"DS++: A flexible, scalable and provably tight relaxation for matching problems"
-----------------------------------------------------------------------------------------------------------------